# Config Object for Jupyter at Rubin Observatory

