"""
Version information.
"""
version_info = (0, 30, 0)
__version__ = ".".join(map(str, version_info))
